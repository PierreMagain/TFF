const prefix = ["section1","section2"];

for (let i = 0; i < prefix.length; i++){
  createToggleLink(prefix[i]);
}
